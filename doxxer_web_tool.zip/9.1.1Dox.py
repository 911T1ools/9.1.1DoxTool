import os
import webbrowser

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main_menu():
    while True:
        clear_screen()
        print("======                                                             ========")
        print("DoXXeR                                                             9.1.1 Tool")
        print("======                                                             ========\n")
        print("1. Name Search")
        print("2. Phone number Search (Germany)")
        print("3. IP Look UP\n")
        answer = input("Option: ").strip()

        if answer == "1":
            name_search()
        elif answer == "2":
            phone_search()
        elif answer == "3":
            ip_lookup()
        else:
            print("Invalid option. Try again.")
            input("Press Return to continue...")

def name_search():
    clear_screen()
    print("===========\nName Search\n===========\n")
    name = input("Type Name: ").strip()
    url = f"https://www.whitepages.com/name/{name}?fs=1&q={name}"
    webbrowser.open(url)
    input("Press Return to go back...")

def phone_search():
    clear_screen()
    print("============\nPhone Search (Germany)\n============\n")
    number = input("Type Number (z. B. 0301234567 oder 017612345678): ").strip()

    tellows_url = f"https://www.tellows.de/num/{number}"
    telefonbuch_url = f"https://www.dastelefonbuch.de/Rückwärtssuche/{number}"

    print("\nOpening number search in browser...")
    webbrowser.open(tellows_url)
    webbrowser.open_new_tab(telefonbuch_url)

    input("Press Return to go back...")

def ip_lookup():
    clear_screen()
    print("=========\nIP Search\n=========\n")
    ip = input("Type IP: ").strip()
    url = f"https://whatismyipaddress.com/ip/{ip}"
    webbrowser.open(url)
    input("Press Return to go back...")

if __name__ == "__main__":
    main_menu()
